from django.shortcuts import render

# Create your views here.
def farmer_home(request):
    return render(request, 'farmer_home/farmer_home.html')

def send_warehouse(request):
    return render(request, 'farmer_home/send_warehouse.html')

def summary(request):
    return render(request, 'farmer_home/summary.html')

def warehouse_full(request):
    return render(request, 'farmer_home/warehouse_full.html')

def farmer_help(request):
    return render(request, 'farmer_home/farmer_help.html')