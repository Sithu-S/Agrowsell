from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class Send_Warehouse(UserCreationForm):
    quantity = forms.CharField(max_length=20)
    produce_type = forms.CharField(max_length=50)
    CHOICES = [('P','Pick One'),('U','Udupi'),('M','Mangalore')]
    select_warehouse = forms.CharField(label='Choose Warehouse Location', widget=forms.Select(choices=CHOICES))
    PICKUP_CHOICES = [('N','NO'),('Y','YES')]
    pickup = forms.CharField(label='Pickup?', widget=forms.Select(choices=PICKUP_CHOICES))
    address = forms.CharField(max_length=200)

    class Meta: 
        model = User
        fields = ["quantity", "produce_type", "select_warehouse", "pickup", "address"]