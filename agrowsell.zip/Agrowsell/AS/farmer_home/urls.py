from django.urls import path
from . import views

urlpatterns = [
    path('farmer_home/', views.farmer_home, name='farmer_home'),
    path('send_warehouse/', views.send_warehouse, name='send_warehouse'),
    path('summary/', views.summary, name='summary'),
    path('warehouse_full/', views.warehouse_full, name='warehouse_full'),
    path('farmer_help/', views.farmer_help, name='farmer_help'),
]