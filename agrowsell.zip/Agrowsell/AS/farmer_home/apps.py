from django.apps import AppConfig


class FarmerHomeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'farmer_home'
