from django.urls import path
from . import views

urlpatterns = [
    path('warehouse_home/', views.warehouse_home, name='warehouse_home'),
    path('capacity/', views.capacity, name='capacity'),
    path('own_warehouse_capacity/', views.own_warehouse_capacity, name='own_warehouse_capacity'),
    path('tracking_produce/', views.tracking_produce, name='tracking_produce'),
    path('transaction_history/', views.transaction_history, name='transaction_history'),
]