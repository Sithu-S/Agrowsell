from django.shortcuts import render

# Create your views here.
def warehouse_home(request):
    return render(request, 'warehouse_home/warehouse_home.html')

def capacity(request):
    return render(request, 'warehouse_home/capacity.html')

def own_warehouse_capacity(request):
    return render(request, 'warehouse_home/own_warehouse_capacity.html')

def tracking_produce(request):
    return render(request, 'warehouse_home/tracking_produce.html')

def transaction_history(request):
    return render(request, 'warehouse_home/transaction_history.html')