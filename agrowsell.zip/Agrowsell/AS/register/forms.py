from django import forms
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class RegisterForm(UserCreationForm):
    phone = forms.CharField(max_length=12)
    CHOICES = [('P','Pick One'),('F','Farmer'),('W','Warehouse Manager')]
    role = forms.CharField(label='Choose your Role', widget=forms.Select(choices=CHOICES))

    class Meta: 
        model = User
        fields = ["username", "phone", "role", "password1", "password2"]